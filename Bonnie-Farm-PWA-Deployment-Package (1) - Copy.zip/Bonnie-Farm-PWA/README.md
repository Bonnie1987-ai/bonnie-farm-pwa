# Bonnie Farm PWA deployment package

Files:
- index.html
- app.js
- sw.js
- manifest.json
- icons/icon-192.png
- icons/icon-512.png
- .nojekyll

## Before GitHub Pages
1. Deploy the separate Bonnie Farm Apps Script backend as a Web App.
2. Copy its `/exec` URL.
3. Open `app.js`.
4. Replace `PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE`.
5. Replace `REPLACE_WITH_YOUR_BONNIE_FARM_APP_KEY` with the same key used by Apps Script.

## GitHub Pages
1. Create a repository such as `bonnie-farm-pwa`.
2. Upload the package contents to the repository root.
3. Settings -> Pages.
4. Build and deployment -> Deploy from a branch.
5. Branch: `main`; folder: `/ (root)`; Save.
6. Open the published `https://YOUR-USERNAME.github.io/bonnie-farm-pwa/` URL.
7. First open must be online so the service worker can cache the app.
8. Use Install Bonnie Farm App.
9. Turn Internet off and test entry.
10. Turn Internet on and Synchronise.

Do not put passwords, service-account keys or other private credentials in the repository.
