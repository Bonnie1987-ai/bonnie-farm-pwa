# Bonnie Farm Poultry Management System — Version 1.0

GitHub Pages PWA for poultry farm management.

## Modules
Dashboard → Flock → Daily Egg Production → Feed → Sales/POS → Expenses → Health → Inventory → Reports → Offline Sync → User Login.

## Deployment
1. Upload the repository contents to `Bonnie1987-ai/bonnie-farm-pwa`.
2. Enable GitHub Pages from the repository Settings → Pages and publish from the branch/folder containing `index.html`.
3. Create a Google Sheet and Apps Script project using `apps-script/Code.gs`.
4. Set `SPREADSHEET_ID` and `API_KEY`, run `setupDatabase()`, then `createDefaultAdmin()`.
5. Deploy Apps Script as a Web app and copy its `/exec` URL.
6. Open Bonnie Farm → Settings and paste the Web App URL and application API key.
7. Test the API.
8. Change the default admin password before production use.

## Important
GitHub Pages is static hosting. Sensitive credentials and private database data must not be placed in the repository. This V1 login is a basic application-level login; production deployments should use a proper identity provider and stronger server-side authentication.
