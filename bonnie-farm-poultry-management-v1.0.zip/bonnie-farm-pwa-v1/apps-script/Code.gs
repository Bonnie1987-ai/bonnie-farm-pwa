/**
 * BONNIE FARM POULTRY MANAGEMENT SYSTEM
 * Version 1.0
 *
 * 1. Create/open a Google Sheet.
 * 2. Extensions -> Apps Script.
 * 3. Paste this file into Code.gs.
 * 4. Set SPREADSHEET_ID and API_KEY.
 * 5. Run setupDatabase() once and authorise it.
 * 6. Deploy -> New deployment -> Web app.
 *    Execute as: Me
 *    Who has access: Anyone (or your organisation as appropriate).
 *
 * IMPORTANT:
 * This V1 endpoint uses GET requests so a GitHub Pages frontend can
 * communicate without depending on browser preflight/CORS behaviour.
 * Do not send highly sensitive information in query strings.
 * For production-grade authentication, move authentication to OAuth/Firebase/
 * another identity provider rather than treating API_KEY as a secret.
 */

const SPREADSHEET_ID = 'PASTE_YOUR_GOOGLE_SHEET_ID_HERE';
const API_KEY = 'CHANGE_THIS_TO_A_LONG_RANDOM_APPLICATION_KEY';

const SHEETS = {
  FLOCK: ['RecordID','Date','FlockID','BirdType','Breed','Event','Number','House','AgeWeeks','Remarks','CreatedAt','Username'],
  EGG: ['RecordID','Date','FlockID','LiveHens','GoodEggs','BrokenEggs','DirtyEggs','TotalEggs','LayingPct','Remarks','CreatedAt','Username'],
  FEED: ['RecordID','Date','Direction','FeedType','QuantityKg','UnitCost','Party','Remarks','CreatedAt','Username'],
  SALE: ['RecordID','Date','Product','Quantity','UnitPrice','Total','Payment','Cashier','Customer','CreatedAt','Username'],
  EXPENSE: ['RecordID','Date','Supplier','Amount','PaidBy','Category','Quantity','Description','CreatedAt','Username'],
  HEALTH: ['RecordID','Date','FlockID','Event','Product','Dose','Cost','WithdrawalDays','Veterinarian','Details','CreatedAt','Username'],
  INVENTORY: ['RecordID','Date','Item','Movement','Quantity','Unit','Reference','Remarks','CreatedAt','Username'],
  Users: ['Username','PasswordHash','Role','Active','CreatedAt']
};

function doGet(e) {
  try {
    const p = e && e.parameter ? e.parameter : {};
    const action = p.action || 'ping';
    if (action !== 'login' && p.apiKey !== API_KEY) return json({ok:false,error:'Invalid API key.'});

    switch(action) {
      case 'ping': return json({ok:true,service:'Bonnie Farm API',version:'1.0.0',time:new Date().toISOString()});
      case 'setup': return json(setupDatabase());
      case 'login': return json(login_(p.username || '', p.password || ''));
      case 'save': return json(save_(p.payload || ''));
      case 'records': return json(getRecords_(p.type || ''));
      case 'summary': return json(summary_());
      default: return json({ok:false,error:'Unknown action.'});
    }
  } catch(err) {
    return json({ok:false,error:String(err && err.message || err)});
  }
}

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function ss_() {
  if (SPREADSHEET_ID === 'PASTE_YOUR_GOOGLE_SHEET_ID_HERE') throw new Error('Set SPREADSHEET_ID first.');
  return SpreadsheetApp.openById(SPREADSHEET_ID);
}

function setupDatabase() {
  const ss=ss_();
  Object.keys(SHEETS).forEach(name=>{
    let sh=ss.getSheetByName(name);
    if(!sh) sh=ss.insertSheet(name);
    const headers=SHEETS[name];
    sh.getRange(1,1,1,headers.length).setValues([headers]);
    sh.setFrozenRows(1);
  });
  return {ok:true,message:'Database sheets created/updated.'};
}

function sheet_(name) {
  const ss=ss_();
  let sh=ss.getSheetByName(name);
  if(!sh) { setupDatabase(); sh=ss.getSheetByName(name); }
  return sh;
}

function save_(payload) {
  if(!payload) throw new Error('Missing payload.');
  const r=JSON.parse(payload);
  if(!r.id || !r.type || !r.data) throw new Error('Invalid record.');
  const name=r.type;
  if(!SHEETS[name]) throw new Error('Unsupported record type: '+name);
  const sh=sheet_(name);
  const existing=findRecordRow_(sh,r.id);
  const d=r.data;
  const user=(d.username||'unknown');
  const row=recordRow_(name,r,user);
  if(existing>0) sh.getRange(existing,1,1,row.length).setValues([row]);
  else sh.appendRow(row);
  return {ok:true,id:r.id,stored:true};
}

function recordRow_(name,r,user) {
  const d=r.data||{};
  switch(name) {
    case 'FLOCK': return [r.id,d.date,d.flockId,d.birdType,d.breed,d.event,d.number,d.house,d.ageWeeks,d.remarks,r.createdAt,user];
    case 'EGG': return [r.id,d.date,d.flockId,d.liveHens,d.goodEggs,d.brokenEggs,d.dirtyEggs,d.totalEggs,d.layingPct,d.remarks,r.createdAt,user];
    case 'FEED': return [r.id,d.date,d.direction,d.feedType,d.quantity,d.unitCost,d.party,d.remarks,r.createdAt,user];
    case 'SALE': return [r.id,d.date,d.product,d.quantity,d.unitPrice,d.total,d.payment,d.cashier,d.customer,r.createdAt,user];
    case 'EXPENSE': return [r.id,d.date,d.supplier,d.amount,d.paidBy,d.category,d.quantity,d.description,r.createdAt,user];
    case 'HEALTH': return [r.id,d.date,d.flockId,d.event,d.product,d.dose,d.cost,d.withdrawalDays,d.veterinarian,d.details,r.createdAt,user];
    case 'INVENTORY': return [r.id,d.date,d.item,d.movement,d.quantity,d.unit,d.reference,d.remarks,r.createdAt,user];
  }
}

function findRecordRow_(sh,id) {
  if(sh.getLastRow()<2) return -1;
  const ids=sh.getRange(2,1,sh.getLastRow()-1,1).getValues().flat();
  const i=ids.indexOf(id);
  return i<0?-1:i+2;
}

function getRecords_(type) {
  if(!SHEETS[type]) throw new Error('Unsupported type.');
  const sh=sheet_(type), values=sh.getDataRange().getValues();
  return {ok:true,type,headers:values.shift()||[],rows:values};
}

function sha256_(text) {
  const bytes=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,text,Utilities.Charset.UTF_8);
  return bytes.map(b=>('0'+(b&0xff).toString(16)).slice(-2)).join('');
}

function login_(username,password) {
  if(!username || !password) return {ok:false,error:'Username and password are required.'};
  const sh=sheet_('Users');
  const values=sh.getDataRange().getValues();
  const target=values.slice(1).find(r=>String(r[0]).toLowerCase()===username.toLowerCase());
  if(!target || String(target[3]).toUpperCase()!=='TRUE') return {ok:false,error:'Invalid login.'};
  if(String(target[1])!==sha256_(password)) return {ok:false,error:'Invalid login.'};
  return {ok:true,user:{username:target[0],role:target[2]}};
}

function summary_() {
  const ss=ss_();
  function total(sheet,col) {
    const sh=ss.getSheetByName(sheet); if(!sh || sh.getLastRow()<2) return 0;
    return sh.getRange(2,col,sh.getLastRow()-1,1).getValues().flat().reduce((a,v)=>a+(Number(v)||0),0);
  }
  return {ok:true,sales:total('SALE',6),expenses:total('EXPENSE',4),eggs:total('EGG',8),feedIssuedKg:sumFeedOut_()};
}
function sumFeedOut_() {
  const sh=ss_.getSheetByName('FEED'); if(!sh || sh.getLastRow()<2) return 0;
  return sh.getRange(2,1,sh.getLastRow()-1,8).getValues()
    .filter(r=>String(r[2]).toUpperCase()==='OUT')
    .reduce((a,r)=>a+(Number(r[4])||0),0);
}

/** Run once after setup to create a default admin.
 * Password is admin123 and should be changed before real use.
 */
function createDefaultAdmin() {
  const sh=sheet_('Users');
  const existing=sh.getDataRange().getValues().slice(1).some(r=>String(r[0]).toLowerCase()==='admin');
  if(!existing) sh.appendRow(['admin',sha256_('admin123'),'Administrator','TRUE',new Date()]);
}
