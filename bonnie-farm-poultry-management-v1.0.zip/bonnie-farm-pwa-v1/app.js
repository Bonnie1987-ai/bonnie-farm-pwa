/* Bonnie Farm Poultry Management System - Version 1.0
   Front end: GitHub Pages PWA
   Backend: Google Apps Script Web App
*/
(() => {
  "use strict";

  const CONFIG = {
    APP_NAME: "Bonnie Farm Poultry Management System",
    VERSION: "1.0.0",
    CURRENCY: "UGX",
    API_URL: "", // Paste deployed Apps Script /exec URL here.
    API_KEY: "", // Public application key; never use this as a password.
    DB_NAME: "BonnieFarmOfflineDB",
    DB_VERSION: 1,
    STORE: "records",
    SESSION_KEY: "bf_session",
    USER_KEY: "bf_user"
  };

  const PRODUCTS = [
    ["Eggs",11500,"🥚"],["DO chicks",0,"🐣"],["OM chicks",0,"🐥"],
    ["Manure",0,"💩"],["Feeds",0,"🌾"],["Consultancy",0,"📚"],
    ["Training",0,"🎓"],["Mature Birds",0,"🐔"]
  ];
  const CASHIERS = ["Musa","Bonnie","Mum","Prossy","Tutu"];

  let db, currentUser = null, currentPage = "dashboard";

  const $ = id => document.getElementById(id);
  const today = () => new Date().toISOString().slice(0,10);
  const uid = (prefix="BF") => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
  const money = n => `${CONFIG.CURRENCY} ${Number(n||0).toLocaleString("en-UG")}`;
  const esc = v => String(v ?? "").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
  const num = v => Number(v)||0;

  function toast(msg) {
    $("toast").textContent = msg;
    $("toast").hidden = false;
    setTimeout(()=> $("toast").hidden=true, 2800);
  }

  function onlineUI() {
    const online = navigator.onLine;
    $("offlineBar").hidden = online;
    $("connectionBadge").textContent = online ? "Online" : "Offline";
    $("connectionBadge").className = "status " + (online ? "online":"offline");
  }

  // ---------- IndexedDB ----------
  function openDB() {
    return new Promise((resolve,reject)=>{
      const req = indexedDB.open(CONFIG.DB_NAME, CONFIG.DB_VERSION);
      req.onupgradeneeded = e => {
        const d = e.target.result;
        if (!d.objectStoreNames.contains(CONFIG.STORE)) {
          const s = d.createObjectStore(CONFIG.STORE,{keyPath:"id"});
          s.createIndex("type","type",{unique:false});
          s.createIndex("synced","synced",{unique:false});
          s.createIndex("date","date",{unique:false});
        }
      };
      req.onsuccess = e => { db=e.target.result; resolve(db); };
      req.onerror = () => reject(req.error);
    });
  }
  function putRecord(record) {
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(CONFIG.STORE,"readwrite");
      tx.objectStore(CONFIG.STORE).put({...record,createdAt:record.createdAt||new Date().toISOString()});
      tx.oncomplete=()=>resolve(record); tx.onerror=()=>reject(tx.error);
    });
  }
  function getAll(type=null) {
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(CONFIG.STORE,"readonly"), s=tx.objectStore(CONFIG.STORE);
      const req=type?s.index("type").getAll(type):s.getAll();
      req.onsuccess=()=>resolve(req.result||[]); req.onerror=()=>reject(req.error);
    });
  }
  async function pendingRecords() {
    return (await getAll()).filter(r=>!r.synced);
  }
  async function markSynced(ids) {
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(CONFIG.STORE,"readwrite"), s=tx.objectStore(CONFIG.STORE);
      ids.forEach(id=>{const g=s.get(id);g.onsuccess=()=>{if(g.result){g.result.synced=true;s.put(g.result)}}});
      tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);
    });
  }

  // ---------- API ----------
  async function apiGet(action, params={}) {
    if (!CONFIG.API_URL) throw new Error("Apps Script API URL is not configured.");
    const q = new URLSearchParams({action,apiKey:CONFIG.API_KEY,...params});
    const res = await fetch(`${CONFIG.API_URL}?${q.toString()}`,{cache:"no-store"});
    if (!res.ok) throw new Error(`API HTTP ${res.status}`);
    const data = await res.json();
    if (!data.ok) throw new Error(data.error||"API error");
    return data;
  }

  async function saveRecord(type, data) {
    const record={id:uid(type),type,date:data.date||today(),data,synced:false};
    await putRecord(record);
    if (navigator.onLine && CONFIG.API_URL) {
      try { await apiGet("save",{payload:JSON.stringify(record)}); await markSynced([record.id]); }
      catch(e) { console.warn(e); toast("Saved locally; will sync later."); }
    } else toast("Saved offline.");
    await renderPage(currentPage);
  }

  async function syncNow() {
    const pending=await pendingRecords();
    if (!pending.length){toast("Nothing to synchronise.");return;}
    if (!navigator.onLine){toast("Still offline.");return;}
    if (!CONFIG.API_URL){toast("Configure the Apps Script API URL first.");return;}
    let done=[];
    for (const r of pending) {
      try { await apiGet("save",{payload:JSON.stringify(r)}); done.push(r.id); }
      catch(e){ console.warn(e); break; }
    }
    if(done.length) await markSynced(done);
    toast(`${done.length} record(s) synchronised.`);
    await renderPage(currentPage);
  }

  // ---------- Navigation ----------
  const navItems = [...document.querySelectorAll(".nav-item[data-page]")];
  function showPage(page) {
    currentPage=page;
    document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===page));
    navItems.forEach(n=>n.classList.toggle("active",n.dataset.page===page));
    $("sidebar").classList.remove("open");
    renderPage(page);
  }

  // ---------- Rendering ----------
  async function renderPage(page) {
    if (!currentUser) return;
    const fn = renderers[page] || renderDashboard;
    await fn();
  }

  async function renderDashboard() {
    const all=await getAll();
    const eggs=all.filter(r=>r.type==="EGG").map(r=>r.data);
    const sales=all.filter(r=>r.type==="SALE").map(r=>r.data);
    const expenses=all.filter(r=>r.type==="EXPENSE").map(r=>r.data);
    const feed=all.filter(r=>r.type==="FEED").map(r=>r.data);
    const flocks=all.filter(r=>r.type==="FLOCK").map(r=>r.data);
    const totalEggs=eggs.reduce((a,r)=>a+num(r.totalEggs),0);
    const totalSales=sales.reduce((a,r)=>a+num(r.total),0);
    const totalExpenses=expenses.reduce((a,r)=>a+num(r.amount),0);
    const currentBirds=flocks.reduce((a,r)=>a+num(r.number),0);
    const feedKg=feed.filter(r=>r.direction==="OUT").reduce((a,r)=>a+num(r.quantity),0);

    $("dashboard").innerHTML=`
      <div class="page-title"><div><h2>Dashboard</h2><div class="muted">Bonnie Farm — Version 1.0</div></div><div class="actions"><button class="btn primary" data-go="eggs">+ Egg record</button><button class="btn" data-go="sales">+ Sale</button></div></div>
      <div class="grid kpi-grid">
        ${kpi("🐔","Current birds",currentBirds,"From local flock records")}
        ${kpi("🥚","Eggs recorded",totalEggs,"All saved egg records")}
        ${kpi("🌾","Feed issued",`${feedKg.toLocaleString()} kg`,"From feed records")}
        ${kpi("💰","Sales",money(totalSales),"Saved sales")}
        ${kpi("💸","Expenses",money(totalExpenses),"Saved expenses")}
        ${kpi("📈","Balance",money(totalSales-totalExpenses),"Sales minus expenses")}
      </div>
      <div class="grid two section-gap">
        <div class="card"><h3>Recent activity</h3>${recentTable(all)}</div>
        <div class="card"><h3>Egg production trend</h3>${eggBars(eggs)}</div>
      </div>
      <div class="card section-gap"><h3>System status</h3><p>Network: <b>${navigator.onLine?"Online":"Offline"}</b></p><p>Unsynchronised records: <b>${(await pendingRecords()).length}</b></p><p class="muted small">Records are stored locally first. When an Apps Script endpoint is configured, saved records are synchronised to Google Sheets.</p></div>`;
    bindPageButtons();
  }

  function kpi(icon,label,value,sub){return `<div class="card kpi"><div class="label">${icon} ${label}</div><div class="value">${esc(value)}</div><div class="sub">${esc(sub)}</div></div>`}
  function recentTable(all){
    const rows=all.sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))).slice(0,8);
    if(!rows.length)return `<p class="muted">No records yet.</p>`;
    return `<div class="table-wrap"><table class="table"><thead><tr><th>Date</th><th>Type</th><th>Status</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.date)}</td><td>${esc(r.type)}</td><td>${r.synced?'<span class="ok">Synced</span>':'<span class="error">Pending</span>'}</td></tr>`).join("")}</tbody></table></div>`;
  }
  function eggBars(rows){
    const recent=rows.slice(-14); if(!recent.length)return `<p class="muted">Add daily egg records to see the chart.</p>`;
    const max=Math.max(1,...recent.map(r=>num(r.totalEggs)));
    return `<div class="bar-chart">${recent.map(r=>`<div class="bar" style="height:${Math.max(8,num(r.totalEggs)/max*90)}%" title="${esc(r.date)}: ${num(r.totalEggs)} eggs"><span>${esc(String(r.date).slice(5))}</span></div>`).join("")}</div>`;
  }

  async function renderFlock(){
    const rows=await getAll("FLOCK");
    $("flock").innerHTML=`${title("Flock Management","Register flocks, additions, mortality and culling.")}<div class="card"><form id="flockForm" class="form-grid">
      <label>Flock ID<input name="flockId" required placeholder="BF-LAY-001"></label>
      <label>Bird type<select name="birdType"><option>Layers</option><option>Broilers</option><option>Chicks</option><option>Breeders</option><option>Other</option></select></label>
      <label>Breed<input name="breed" placeholder="ISA Brown"></label><label>Date<input name="date" type="date" value="${today()}"></label>
      <label>Event<select name="event"><option>Opening/Received</option><option>Addition</option><option>Mortality</option><option>Culling</option><option>Transfer in</option><option>Transfer out</option></select></label>
      <label>Number<input name="number" type="number" min="0" required></label><label>House<input name="house" placeholder="Layer House 1"></label><label>Age (weeks)<input name="ageWeeks" type="number" min="0"></label>
      <label class="wide">Remarks<textarea name="remarks"></textarea></label><div class="form-actions"><button class="btn primary">Save flock event</button></div></form></div>
      <div class="card section-gap"><h3>Flock records</h3>${table(rows,["date","flockId","event","number","house","birdType"])}</div>`;
    $("flockForm").onsubmit=e=>{e.preventDefault();saveRecord("FLOCK",Object.fromEntries(new FormData(e.target)))};
  }

  async function renderEggs(){
    const rows=await getAll("EGG");
    $("eggs").innerHTML=`${title("Daily Egg Production","Record daily production and automatically calculate laying percentage.")}<div class="card"><form id="eggForm" class="form-grid">
      <label>Date<input name="date" type="date" value="${today()}" required></label><label>Flock ID<input name="flockId" required placeholder="BF-LAY-001"></label><label>Live hens<input name="liveHens" type="number" min="0" required></label><label>Good eggs<input name="goodEggs" type="number" min="0" required></label>
      <label>Broken eggs<input name="brokenEggs" type="number" min="0" value="0"></label><label>Dirty eggs<input name="dirtyEggs" type="number" min="0" value="0"></label><label>Total eggs<input name="totalEggs" id="eggTotal" type="number" readonly></label><label>Hen-day %<input name="layingPct" id="layingPct" readonly></label>
      <label class="wide">Remarks<textarea name="remarks"></textarea></label><div class="form-actions"><button class="btn primary">Save daily production</button></div></form></div>
      <div class="card section-gap"><h3>Egg records</h3>${table(rows,["date","flockId","liveHens","goodEggs","brokenEggs","dirtyEggs","totalEggs","layingPct"])}</div>`;
    const f=$("eggForm"), calc=()=>{const good=num(f.goodEggs.value),broken=num(f.brokenEggs.value),dirty=num(f.dirtyEggs.value),hens=num(f.liveHens.value);f.totalEggs.value=good+broken+dirty;f.layingPct.value=hens?((good+broken+dirty)/hens*100).toFixed(2):"0.00"};
    f.oninput=calc; f.onsubmit=e=>{e.preventDefault();calc();saveRecord("EGG",Object.fromEntries(new FormData(f)))};
  }

  async function renderFeed(){
    const rows=await getAll("FEED");
    $("feed").innerHTML=`${title("Feed Management","Track feed purchases, issues and stock.")}<div class="card"><form id="feedForm" class="form-grid">
      <label>Date<input name="date" type="date" value="${today()}"></label><label>Direction<select name="direction"><option value="IN">Purchase / IN</option><option value="OUT">Issued / OUT</option></select></label><label>Feed type<input name="feedType" required placeholder="Layer mash"></label><label>Quantity (kg)<input name="quantity" type="number" min="0" step="0.01" required></label>
      <label>Unit cost (UGX)<input name="unitCost" type="number" min="0"></label><label>Supplier/House<input name="party" placeholder="Supplier or house"></label><label class="wide">Remarks<textarea name="remarks"></textarea></label><div class="form-actions"><button class="btn primary">Save feed record</button></div></form></div>
      <div class="card section-gap"><h3>Feed records</h3>${table(rows,["date","direction","feedType","quantity","unitCost","party"])}</div>`;
    $("feedForm").onsubmit=e=>{e.preventDefault();saveRecord("FEED",Object.fromEntries(new FormData(e.target)))};
  }

  async function renderSales(){
    const rows=await getAll("SALE");
    $("sales").innerHTML=`${title("Sales / POS","Record farm sales in Uganda shillings.")}<div class="card"><h3>Quick POS</h3><div class="pos-products">${PRODUCTS.map((p,i)=>`<button class="product-card" data-product="${esc(p[0])}" data-price="${p[1]}"><div style="font-size:40px">${p[2]}</div><strong>${esc(p[0])}</strong><span>${p[1]?money(p[1]):"Set price"}</span></button>`).join("")}</div></div>
      <div class="card section-gap"><form id="saleForm" class="form-grid">
      <label>Date<input name="date" type="date" value="${today()}"></label><label>Product<select name="product">${PRODUCTS.map(p=>`<option>${esc(p[0])}</option>`).join("")}</select></label><label>Quantity<input name="quantity" type="number" min="0" step="0.01" required></label><label>Unit price (UGX)<input name="unitPrice" type="number" min="0" required></label>
      <label>Payment<select name="payment"><option>Cash</option><option>Mobile Money</option><option>Bank</option><option>Credit</option></select></label><label>Cashier<select name="cashier">${CASHIERS.map(c=>`<option>${c}</option>`).join("")}</select></label><label>Customer<input name="customer"></label><label>Total (UGX)<input name="total" readonly></label>
      <div class="form-actions"><button class="btn primary">Complete sale</button></div></form></div>
      <div class="card section-gap"><h3>Sales records</h3>${table(rows,["date","product","quantity","unitPrice","total","payment","cashier"])}</div>`;
    const f=$("saleForm");const calc=()=>f.total.value=(num(f.quantity.value)*num(f.unitPrice.value)).toFixed(0);f.oninput=calc;
    document.querySelectorAll("[data-product]").forEach(b=>b.onclick=()=>{f.product.value=b.dataset.product;if(num(b.dataset.price)>0)f.unitPrice.value=b.dataset.price;calc()});
    f.onsubmit=e=>{e.preventDefault();calc();saveRecord("SALE",Object.fromEntries(new FormData(f)))};
  }

  async function renderExpenses(){
    const rows=await getAll("EXPENSE");
    $("expenses").innerHTML=`${title("Expenses","Track farm operating expenditure.")}<div class="card"><form id="expenseForm" class="form-grid">
      <label>Date<input name="date" type="date" value="${today()}"></label><label>Payee/Supplier<input name="supplier" required></label><label>Amount (UGX)<input name="amount" type="number" min="0" required></label><label>Paid by<select name="paidBy"><option>Bonnie</option><option>Musa</option><option>Mum</option><option>Prossy</option><option>Tutu</option><option>Other</option></select></label>
      <label>Category<select name="category"><option>Feed</option><option>Drugs</option><option>Vaccines</option><option>Labour</option><option>Transport</option><option>Utilities</option><option>Repairs</option><option>Equipment</option><option>Other</option></select></label><label>Quantity<input name="quantity" type="number" min="0" step="0.01"></label><label class="wide">Description<textarea name="description"></textarea></label><div class="form-actions"><button class="btn primary">Save expense</button></div></form></div>
      <div class="card section-gap"><h3>Expense records</h3>${table(rows,["date","supplier","amount","paidBy","category","quantity","description"])}</div>`;
    $("expenseForm").onsubmit=e=>{e.preventDefault();saveRecord("EXPENSE",Object.fromEntries(new FormData(e.target)))};
  }

  async function renderHealth(){
    const rows=await getAll("HEALTH");
    $("health").innerHTML=`${title("Health","Record vaccination, disease and treatment events.")}<div class="card"><form id="healthForm" class="form-grid">
      <label>Date<input name="date" type="date" value="${today()}"></label><label>Flock ID<input name="flockId" required></label><label>Type<select name="event"><option>Vaccination</option><option>Disease</option><option>Treatment</option><option>Veterinary visit</option></select></label><label>Drug/Vaccine<input name="product"></label>
      <label>Dose<input name="dose"></label><label>Cost (UGX)<input name="cost" type="number" min="0"></label><label>Withdrawal period (days)<input name="withdrawalDays" type="number" min="0"></label><label>Veterinarian<input name="veterinarian"></label>
      <label class="wide">Signs / diagnosis / treatment<textarea name="details"></textarea></label><div class="form-actions"><button class="btn primary">Save health record</button></div></form></div>
      <div class="card section-gap"><h3>Health records</h3>${table(rows,["date","flockId","event","product","dose","cost","withdrawalDays","veterinarian","details"])}</div>`;
    $("healthForm").onsubmit=e=>{e.preventDefault();saveRecord("HEALTH",Object.fromEntries(new FormData(e.target)))};
  }

  async function renderInventory(){
    const rows=await getAll("INVENTORY");
    $("inventory").innerHTML=`${title("Inventory","Record stock movements and monitor balances.")}<div class="card"><form id="inventoryForm" class="form-grid">
      <label>Date<input name="date" type="date" value="${today()}"></label><label>Item<input name="item" required placeholder="Egg trays"></label><label>Movement<select name="movement"><option>IN</option><option>OUT</option><option>ADJUSTMENT</option></select></label><label>Quantity<input name="quantity" type="number" min="0" step="0.01" required></label>
      <label>Unit<input name="unit" placeholder="kg, pcs, doses"></label><label>Reference<input name="reference" placeholder="Invoice / issue note"></label><label class="wide">Remarks<textarea name="remarks"></textarea></label><div class="form-actions"><button class="btn primary">Save stock movement</button></div></form></div>
      <div class="card section-gap"><h3>Inventory movements</h3>${table(rows,["date","item","movement","quantity","unit","reference","remarks"])}</div>`;
    $("inventoryForm").onsubmit=e=>{e.preventDefault();saveRecord("INVENTORY",Object.fromEntries(new FormData(e.target)))};
  }

  async function renderReports(){
    const all=await getAll();const start=today().slice(0,7);
    const sales=all.filter(r=>r.type==="SALE"&&String(r.date).startsWith(start)).reduce((a,r)=>a+num(r.data.total),0);
    const exp=all.filter(r=>r.type==="EXPENSE"&&String(r.date).startsWith(start)).reduce((a,r)=>a+num(r.data.amount),0);
    const eggs=all.filter(r=>r.type==="EGG"&&String(r.date).startsWith(start)).reduce((a,r)=>a+num(r.data.totalEggs),0);
    $("reports").innerHTML=`${title("Reports","Monthly summary for ${start}.")}<div class="grid three"><div class="card kpi"><div class="label">Sales</div><div class="value">${money(sales)}</div></div><div class="card kpi"><div class="label">Expenses</div><div class="value">${money(exp)}</div></div><div class="card kpi"><div class="label">Net</div><div class="value">${money(sales-exp)}</div></div></div>
      <div class="card section-gap"><h3>Production</h3><p>Total eggs recorded this month: <b>${eggs.toLocaleString()}</b></p><p>Unsynchronised records: <b>${(await pendingRecords()).length}</b></p><button class="btn" onclick="window.print()">Print report</button></div>`;
  }

  async function renderSettings(){
    $("settings").innerHTML=`${title("Settings","Configure the connection and application preferences.")}<div class="card"><form id="settingsForm" class="form-grid">
      <label class="wide">Google Apps Script Web App URL<input name="apiUrl" value="${esc(localStorage.getItem("bf_api_url")||CONFIG.API_URL)}" placeholder="https://script.google.com/macros/s/.../exec"></label>
      <label>Application API key<input name="apiKey" value="${esc(localStorage.getItem("bf_api_key")||CONFIG.API_KEY)}"></label>
      <div class="form-actions"><button class="btn primary">Save connection</button><button type="button" class="btn" id="testApi">Test API</button></div>
    </form><hr><p><b>Current user:</b> ${esc(currentUser.username)} (${esc(currentUser.role)})</p><p><b>Version:</b> ${CONFIG.VERSION}</p><p class="muted small">Do not place private passwords or service-account credentials in GitHub.</p></div>`;
    $("settingsForm").onsubmit=e=>{e.preventDefault();const f=new FormData(e.target);localStorage.setItem("bf_api_url",f.get("apiUrl"));localStorage.setItem("bf_api_key",f.get("apiKey"));toast("Connection settings saved.");};
    $("testApi").onclick=async()=>{try{await apiGet("ping");toast("API connection successful.");}catch(e){toast(e.message)}};
  }

  const renderers={dashboard:renderDashboard,flock:renderFlock,eggs:renderEggs,feed:renderFeed,sales:renderSales,expenses:renderExpenses,health:renderHealth,inventory:renderInventory,reports:renderReports,settings:renderSettings};

  function title(h,sub){return `<div class="page-title"><div><h2>${h}</h2><div class="muted">${sub}</div></div></div>`}
  function table(rows,keys){
    if(!rows.length)return `<p class="muted">No records yet.</p>`;
    return `<div class="table-wrap"><table class="table"><thead><tr>${keys.map(k=>`<th>${esc(k)}</th>`).join("")}</tr></thead><tbody>${rows.slice().reverse().slice(0,100).map(r=>`<tr>${keys.map(k=>`<td>${esc(r.data?.[k]??r[k]??"")}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
  }
  function bindPageButtons(){document.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>showPage(b.dataset.go));}

  // ---------- Login ----------
  async function login(username,password){
    // V1 supports a local demo administrator when no API is configured.
    // Once API is configured, authentication is checked by Apps Script.
    if(!CONFIG.API_URL && username==="admin" && password==="admin123"){
      currentUser={username:"admin",role:"Administrator",local:true};
    } else {
      const data=await apiGet("login",{username,password});
      currentUser=data.user;
    }
    localStorage.setItem(CONFIG.USER_KEY,JSON.stringify(currentUser));
    $("loginView").hidden=true;$("appView").hidden=false;
    $("userBadge").textContent=`${currentUser.username} • ${currentUser.role}`;
    showPage("dashboard");
  }

  function logout(){
    currentUser=null;localStorage.removeItem(CONFIG.USER_KEY);
    $("appView").hidden=true;$("loginView").hidden=false;
  }

  async function init(){
    await openDB();
    CONFIG.API_URL=localStorage.getItem("bf_api_url")||CONFIG.API_URL;
    CONFIG.API_KEY=localStorage.getItem("bf_api_key")||CONFIG.API_KEY;
    onlineUI();
    window.addEventListener("online",()=>{onlineUI();syncNow()});
    window.addEventListener("offline",onlineUI);
    navItems.forEach(n=>n.onclick=()=>showPage(n.dataset.page));
    $("menuBtn").onclick=()=>$("sidebar").classList.toggle("open");
    $("syncBtn").onclick=syncNow;
    $("logoutBtn").onclick=logout;
    $("loginForm").onsubmit=async e=>{
      e.preventDefault();$("loginMessage").textContent="Signing in...";
      try{await login($("loginUsername").value.trim(),$("loginPassword").value);$("loginMessage").textContent=""}
      catch(err){$("loginMessage").className="message error";$("loginMessage").textContent=err.message||"Login failed."}
    };
    const saved=localStorage.getItem(CONFIG.USER_KEY);
    if(saved){try{currentUser=JSON.parse(saved);$("loginView").hidden=true;$("appView").hidden=false;$("userBadge").textContent=`${currentUser.username} • ${currentUser.role}`;showPage("dashboard")}catch{}}
    if("serviceWorker" in navigator) navigator.serviceWorker.register("./sw.js").catch(console.warn);
  }
  document.addEventListener("DOMContentLoaded",init);
})();